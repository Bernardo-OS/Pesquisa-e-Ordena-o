telefone = {'num_celular': '', 'dados_sessao' : ''}

#caminho_arquivo = string(input("Informe o caminho do arquo"))
caminho_arquivo = "aasd"

