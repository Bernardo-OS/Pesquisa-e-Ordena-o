def ler_arquivo(caminho):
    objetos = []

    with open(caminho, "r", encoding="utf-8") as arquivo:
        for linha in arquivo:
            linha = linha.strip()

            if not linha:
                continue

            num_telefone, dados_sessao = linha.split(";", 1)

            objetos.append({
                "num_telefone": num_telefone,
                "dados_sessao": dados_sessao
            })

    return objetos